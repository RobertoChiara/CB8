Ciao o tu povero sventurato che dovrai rivedere e correggere una trentina di progeti di neofiti!

Allora, ho cercato di seguire le consegne (incluse le avanzate e qualcosina in più, giusto per allenarmi)

1) Design palette etc sono scritte all'inizio del CSS.
2) L'header ok, logo a Sx e pulsanti nav a Dx (ho provato ad aggiungere pulsanti per ogni "sezione" della mia pagina.
3) Sezione Hero ok, unica cosa che non sono a fare è stato di mantenere la background-image della hero che "scalasse" anche in mobile, ma va bene cosi secondo me!
4) Sezione colonne fatte, ne ho aggiunta qualcuna in più per la mia anima da Super Quark.
5) Footer fatto, forse un po piccola ma ho aggiunto qualcosina che mi sembrava carina.

avanzato

1)Tutto fatto non so se avessi dovuto mettere una immagine pure sulal colonna sinistra, ma la pagina mi sembrava già troppo "carica di immagini" e ho preferito mettere un testo sopra al pulsante.
2)Sezione blog fatta ma non sono riuscito a mettere 2 righe da 4 card come nella consegna.


PS, nella pagina ho inserito un TAG Audio e uno Video, 
non so se è un problema mio ma a volte nel live server non partono gli autoplay! Mi si risolve solo cambiando valori nel css per poi rimetterli come erano prima e salvando ripetutamente i 2 files html e css, non ho idea del perchè, spero non capiti a voi.


Grazie! ci vediamo a lezione =) 

Roberto 